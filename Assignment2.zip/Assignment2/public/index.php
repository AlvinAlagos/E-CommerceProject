<?php
    require_once '../app/init.php';
    $init = new App;
?>