<?php
    define('APPROOT', dirname(dirname(__FILE__)));
    define('URLROOT', 'http://localhost/Assignment2');
    define('SITENAME', '420-411-VA: Assignment 2: Blog');

    define('DB_HOST', 'localhost');
    define('DB_USER', 'root');
    define('DB_PASS', '');
    define('DB_NAME', 'blog');