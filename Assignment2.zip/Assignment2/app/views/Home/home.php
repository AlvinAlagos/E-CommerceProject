<?php require APPROOT . '/views/includes/header.php'; 
?>
    <h1>Welcome to our blog</h1>
    <p>This view is invoked by HomeController</p>
<?php require APPROOT . '/views/includes/footer.php'; ?>